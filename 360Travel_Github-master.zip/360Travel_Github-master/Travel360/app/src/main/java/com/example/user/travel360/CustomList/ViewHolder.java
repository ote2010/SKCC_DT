package com.example.user.travel360.CustomList;

import android.widget.ImageView;
import android.widget.TextView;

public class ViewHolder {
    ImageView comment_img;
    TextView comment_id;
    TextView comment_txt;

}
