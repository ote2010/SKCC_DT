package com.example.user.travel360.CustomList;

import android.widget.ImageView;
import android.widget.TextView;

public class MyWriteViewHolder {
    public TextView context_title;
    public TextView context_text;
    public TextView context_location;
    public TextView context_date;
}
