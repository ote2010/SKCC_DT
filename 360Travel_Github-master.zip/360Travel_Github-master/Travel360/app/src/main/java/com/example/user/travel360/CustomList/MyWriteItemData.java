package com.example.user.travel360.CustomList;

import android.graphics.drawable.Drawable;

public class MyWriteItemData {
    public String context_title;
    public String context_text;
    public String context_location;
    public String context_date;
}
