package com.example.user.travel360.CustomList;

import android.graphics.drawable.Drawable;

public class ItemData {
  //  public Bitmap comment_img;
   public Drawable comment_img;
    public String comment_id;
    public String comment_txt;
}
